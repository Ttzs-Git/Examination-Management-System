# README
基础功能:
    release: 1.0.0 

拓展功能:
    1. ANSI转义码 
    release: 1.1.0
    2. 密码登录root权限
    release: 1.2.0
    3. 发布者和订阅者管理
    release: 1.3.0
    4. 支持AI智能分析报告
    release: 1.4.0
    5. 支持GUI
    release: 1.5.0
    6. bugs修复
    release: 1.6.0

未来延展:
    1. 实际场景中大规模考试的统计分析是必要的
    4. 使用数据库
    5. 系统兼容性
    6. 实现密文传输
# 常用指令
lsof -i:8888
kill-9 <PID>